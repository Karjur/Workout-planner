import AppInput from "./AppInput.vue";


export default [AppInput];
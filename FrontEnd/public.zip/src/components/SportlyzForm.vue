<template>
  <div class="py-12 px-4 sm:px-6 lg:px-8 text-dark-300">
    <div class="text-center">
      <h1 class="font-bold">{{ title }}</h1>
      <p>Teretulemast Sportlyz avalehele!</p>
      <p>Edasi vaatamiseks logige sisse.</p>
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{ title: string }>();
</script>

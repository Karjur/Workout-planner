<template>
  <LoginForm />
</template>

<script setup lang="ts">
import LoginForm from '@/components/LoginForm.vue';
</script>

<template>
    <SportlyzForm title="Avaleht" />
</template>

<script setup lang="ts">
import SportlyzForm from '@/components/SportlyzForm.vue';
</script>
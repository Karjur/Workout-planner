<template>
  <div><Navigation /></div>
  <router-view />
</template>

<script setup lang="ts">
import Navigation from './components/Navigation.vue';
</script>
